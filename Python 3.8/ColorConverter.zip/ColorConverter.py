#!/usr/bin/env python3.8

# Color converter
#
# Made by MrClock#8163 to help converting color codes between sRGB[0-255],sRGB[0-1] and linear sRGB[0-1]
#
# GUI runs by the appJar library http://appjar.info/

from appJar import gui

#   FUNCTIONS

# verify that the imput values can be processed with the settings
def fnc_verify(value,colorType,isFullCode):

    # input field is empty
    if value == "":
        return False
    
    
    if isFullCode:
        if len(value) != 3:
            return False
        else:
            for x in value:
                try:
                    float(x)
                except:
                   break
                
                valueFloat = float(x)
                if colorType == "sRGB [0-255]":
                    if not (valueFloat <= 255 and valueFloat >= 0 and (valueFloat % 1) == 0):
                        break
                elif colorType == "sRGB [0-1]" or colorType == "linear RGB [0-1]":
                    if not (valueFloat <= 1 and valueFloat >= 0):
                        break
            else:
                verifiedValues = [float(value[0]),float(value[1]),float(value[2])]
                return verifiedValues
        return False
                
    else:
        if len(value) != 1:
            return False
        else:
            try:
                float(value[0])
            except:
                return False
            
            valueFloat = float(value[0])
            if colorType == "sRGB [0-255]":
                if valueFloat <= 255 and valueFloat >= 0:
                    return [valueFloat]
            elif colorType == "sRGB [0-1]" or colorType == "linear RGB [0-1]":
                if valueFloat <= 1 and valueFloat >= 0:
                    return [valueFloat]

    # if everything fails
    return False

# hand single color and full code
def fnc_convertCaller(value,colorType,isFullCode,convertTo):
    returnValue = ""
    
    if isFullCode:
        returnValue = []
        for x in value:
            returnValue.append(str(fnc_convertColor(x,colorType,convertTo)))
        return " , ".join(returnValue)
        
    else:
        returnValue = fnc_convertColor(value[0],colorType,convertTo)
        return returnValue
    
# convert color and return the new value
def fnc_convertColor(value,colorType,convertTo):
    returnValue = 0
    
    if colorType == convertTo:
        if colorType == "sRGB [0-255]":
            return round(value)
        else:
            return value
    
    if colorType == "sRGB [0-255]":
        if convertTo == "sRGB [0-1]":
            return round(value / 255, 3)
        if convertTo == "linear RGB [0-1]":
            sRGBFormat = round(value/255,3)
            if sRGBFormat <= 0.0404482362771082:
                returnValue = round(sRGBFormat / 12.92, 3)
            else:
                returnValue = round(((sRGBFormat + 0.055) / 1.055) ** 2.4, 3)
            
            return returnValue
            
    if colorType == "sRGB [0-1]":
        if convertTo == "sRGB [0-255]":
            return round(value * 255)
        if convertTo == "linear RGB [0-1]":
            if value <= 0.0404482362771082:
                returnValue = round(value / 12.92, 3)
            else:
                returnValue = round(((value + 0.055) / 1.055) ** 2.4, 3)
            return returnValue
            
    if colorType == "linear RGB [0-1]":
        if convertTo == "sRGB [0-255]":
            if value <= 0.00313066844250063:
                returnValue = round(value * 12.92 * 255)
            else:
                returnValue = round((1.055 * (value ** (1/2.4)) - 0.055) * 255)
                
        if convertTo == "sRGB [0-1]":
            if value <= 0.00313066844250063:
                returnValue = round(value * 12.92, 3)
            else:
                returnValue = round((1.055 * (value ** (1/2.4)) - 0.055), 3)
        return returnValue
    
    return "Error"

# button press handler
def fnc_btn_colorConvert():
    inputValue = app.getEntry("color").split(",")
    verified = fnc_verify(inputValue,app.getOptionBox("colorType"),app.getCheckBox("Full code"))
    
    if verified == False:
        return app.errorBox("Fail","Invalid input")
    else:
        verifiedValues = verified
    
    app.setEntry("sRGB [0-255]",fnc_convertCaller(verifiedValues,app.getOptionBox("colorType"),app.getCheckBox("Full code"),"sRGB [0-255]"))
    app.setEntry("sRGB [0-1]",fnc_convertCaller(verifiedValues,app.getOptionBox("colorType"),app.getCheckBox("Full code"),"sRGB [0-1]"))
    app.setEntry("linear RGB [0-1]",fnc_convertCaller(verifiedValues,app.getOptionBox("colorType"),app.getCheckBox("Full code"),"linear RGB [0-1]"))
    return

#   APP DEFINE
app = gui("Color code converter by MrClock")
app.setResizable(canResize=False)
app.setBg("gray", override=True)

#   INPUT
app.startLabelFrame("")
app.setSticky("ew")

app.startFrame("Frame11", 0, 0)
app.addEntry("color", 0, 0)
app.addOptionBox("colorType",["sRGB [0-255]","sRGB [0-1]","linear RGB [0-1]"], 0, 1)
app.setOptionBoxTooltip("colorType","Type of the input value(s)")
app.addCheckBox("Full code", 0, 2)
app.setCheckBoxTooltip("Full code","TRUE: input is a full color code in 'R,G,B' format | FALSE: input is a single color value")

app.stopFrame()
app.startFrame("Frame12", 1, 0)
app.startFrame("Frame121", 0, 0)
app.addLabelEntry("sRGB [0-255]", 0, 0)
app.addLabelEntry("sRGB [0-1]", 1, 0)
app.addLabelEntry("linear RGB [0-1]", 2, 0)
app.disableEntry("sRGB [0-255]")
app.disableEntry("sRGB [0-1]")
app.disableEntry("linear RGB [0-1]")
app.setEntryTooltip("sRGB [0-255]","Eg.: Photoshop")
app.setEntryTooltip("sRGB [0-1]","Eg.: Arma 3 texture macros")
app.setEntryTooltip("linear RGB [0-1]","Eg.: Substance Painter")
app.stopFrame()
app.startFrame("Frame122", 0, 1)
app.addButton("Convert",fnc_btn_colorConvert, 0, 0)
app.stopFrame()
app.stopFrame()
app.stopLabelFrame()

#   APP LAUNCH
app.go()