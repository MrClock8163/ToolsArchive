Color code converter by MrClock

This tool is mainly intended to help convert between the color codes of Photoshop, Arma 3's texture macros (eg.: "#(argb,8,8,3)color(0.5,0.5,0.5,1,CO)") and Substance Painter
A relatively simple mathematic explanation of the conversion between sRGB [0-1] and linear sRGB [0-1] can be found here: https://entropymine.com/imageworsener/srgbformula/

Colors used in programs:
	-Photoshop: sRGB [0-255]
	-Arma 3 texture macros: sRGB [0-1]
	-Substance Painter: linear sRGB [0-1]

Requirements and credits:
	-Python 3.8 has to be installed on the computer to run the tool
	-the GUI is ran by the appJar library (website: http://appjar.info/)

Use:
	-Unpack the PY file and the appJar folder to a folder you like (recommended to create an own folder for it)-
	-Run the "ColorConverter.py"

Features:
	-conversion of single color channel values (R/G/B) or entire colors (R,G,B)
	-conversion between sRGB [0-255], sRGB [0-1] and linear sRGB [0-1]